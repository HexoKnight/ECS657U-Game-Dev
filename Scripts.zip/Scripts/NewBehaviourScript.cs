using UnityEngine;
using StarterAssets;

[RequireComponent(typeof(CharacterController))]
public class MagnetWalker : MonoBehaviour
{
    [Header("Activation")]
    public LayerMask magneticLayers;
    public string magneticTag = "";
    [Tooltip("Toggle (true) or hold (false).")]
    public bool useToggle = true;
    [Tooltip("Also allow Sprint (from StarterAssetsInputs).")]
    public bool allowSprintAction = true;
    [Tooltip("Keyboard fallback (works if Active Input Handling = Both).")]
    public KeyCode attachKey = KeyCode.E;

    [Header("Robust surface detection")]
    [Tooltip("Search radius around the player to find nearby magnetic colliders.")]
    public float detectRadius = 2.5f;
    [Tooltip("Sphere radius for the outward cast to retrieve a stable normal.")]
    public float probeRadius = 0.35f;
    [Tooltip("Try to hit backfaces (helps if wall triangles face away).")]
    public bool queriesHitBackfaces = true;
    [Tooltip("Minimum tilt from world-up to allow attaching (avoid floors).")]
    [Range(0,90)] public float minSurfaceTiltFromUp = 25f;
    [Tooltip("Max angle between your aim-forward and the wall normal.")]
    [Range(0,90)] public float maxAttachAngle = 80f;

    [Header("Wall locomotion")]
    public float wallMoveSpeed = 4.5f;
    public float stickForce = 34f;
    public float alignUpSlerp = 12f;
    public float inputSmoothing = 12f;
    [Tooltip("Small offset to keep the capsule off the wall.")]
    public float snapOffset = 0.12f;

    [Header("Detach")]
    public float detachDistance = 3.0f;
    [Range(0,90)] public float maxNormalChangeToDetach = 55f;
    public bool alignToWorldUpOnDetach = true;

    [Header("Camera (look)")]
    public Transform cameraTarget; // auto-wired from FPC
    public Vector2 lookSensitivity = new Vector2(1.2f, 1.0f);
    public Vector2 pitchLimits = new Vector2(-80f, 80f);

    [Header("References")]
    public MonoBehaviour firstPersonController; // auto-wired

    [Header("Debug")]
    public bool debugLogging = true;
    public bool drawGizmos = true;

    // --- internals
    private StarterAssetsInputs _inputs;
    private CharacterController  _cc;
    private bool _magnetActive, _toggleLatch;
    private Vector2 _smoothedMove;
    private float _yaw, _pitch;
    private Vector3 _currentNormal = Vector3.up, _lastNormal = Vector3.up;
    private Quaternion _savedCamLocalRot;
    private float _savedStepOffset, _savedSlopeLimit;

    void Awake()
    {
        _inputs = GetComponent<StarterAssetsInputs>();
        _cc     = GetComponent<CharacterController>();

        // Auto-wire FPC + CameraTarget
        if (firstPersonController == null)
        {
            var fpc = GetComponent<FirstPersonController>();
            if (fpc) firstPersonController = fpc;
        }
        if (cameraTarget == null && firstPersonController is FirstPersonController fpcWithTarget && fpcWithTarget.CinemachineCameraTarget)
            cameraTarget = fpcWithTarget.CinemachineCameraTarget.transform;
    }

    void Update()
    {
        HandleActivation();
        if (_magnetActive) TickMagnet();
    }

    private void HandleActivation()
    {
        bool keyDown       = Input.GetKeyDown(attachKey);
        bool sprintPressed = allowSprintAction && _inputs != null && _inputs.sprint;

        if (useToggle)
        {
            if ((keyDown || (sprintPressed && !_toggleLatch)))
            {
                _toggleLatch = true;
                if (_magnetActive) Detach();
                else TryAttach();
            }
            if (_inputs != null && !_inputs.sprint) _toggleLatch = false;
        }
        else
        {
            if ((keyDown || sprintPressed) && !_magnetActive) TryAttach();
            if (!sprintPressed && _magnetActive) Detach();
        }

        // Detach on Jump
        if (_magnetActive && _inputs != null && _inputs.jump)
        {
            Detach();
            _inputs.JumpInput(false);
        }
    }

    private void TryAttach()
    {
        if (FindBestSurface(out var hit))
        {
            // Floor gate
            float tiltFromUp = Vector3.Angle(hit.normal, Vector3.up);
            if (tiltFromUp < minSurfaceTiltFromUp)
            {
                if (debugLogging) Debug.Log("[MagnetWalker] Surface too flat (floor).");
                return;
            }
            // Facing gate
            float aimAngle = Vector3.Angle(-GetAimForward(), hit.normal);
            if (aimAngle > maxAttachAngle)
            {
                if (debugLogging) Debug.Log($"[MagnetWalker] Not facing wall enough ({aimAngle:0.0} > {maxAttachAngle}).");
                return;
            }
            // Optional tag gate
            if (!string.IsNullOrEmpty(magneticTag) && !hit.collider.CompareTag(magneticTag))
            {
                if (debugLogging) Debug.Log("[MagnetWalker] Tag mismatch.");
                return;
            }

            _currentNormal = hit.normal;
            _lastNormal    = hit.normal;

            // Disable FPC (stop gravity/look)
            if (firstPersonController != null) firstPersonController.enabled = false;

            // Harden CC for wall mode
            if (_cc != null)
            {
                _savedStepOffset = _cc.stepOffset;
                _savedSlopeLimit = _cc.slopeLimit;
                _cc.stepOffset   = 0f;
                _cc.slopeLimit   = 90f;
            }

            // Save camera local rot & seed yaw/pitch
            if (cameraTarget != null)
            {
                _savedCamLocalRot = cameraTarget.localRotation;
                Vector3 fFlat = Vector3.ProjectOnPlane(GetAimForward(), _currentNormal).normalized;
                if (fFlat.sqrMagnitude < 1e-4f) fFlat = Vector3.forward;
                _yaw   = SignedAngleOnPlane(transform.forward, fFlat, _currentNormal);
                _pitch = Mathf.Asin(Vector3.Dot(GetAimForward(), _currentNormal)) * Mathf.Rad2Deg;
            }

            _smoothedMove = Vector2.zero;
            _magnetActive = true;

            // Snap slightly off the wall to avoid clipping
            Vector3 snapPos = hit.point + hit.normal * snapOffset;
            Vector3 delta   = snapPos - transform.position;
            _cc.Move(delta); // safe snap using CC

            if (debugLogging) Debug.Log("[MagnetWalker] ATTACHED");
        }
        else
        {
            if (debugLogging) Debug.Log("[MagnetWalker] No magnetic surface found nearby.");
        }
    }

    private void Detach()
    {
        // Restore CC
        if (_cc != null)
        {
            _cc.stepOffset = _savedStepOffset;
            _cc.slopeLimit = _savedSlopeLimit;
        }

        // Restore camera (clear local yaw/roll; keep pitch)
        if (cameraTarget != null)
        {
            cameraTarget.localRotation = _savedCamLocalRot;
            var e = cameraTarget.localEulerAngles;
            cameraTarget.localRotation = Quaternion.Euler(e.x, 0f, 0f);
        }

        // Stand upright
        if (alignToWorldUpOnDetach)
        {
            Vector3 flatFwd = Vector3.ProjectOnPlane(GetAimForward(), Vector3.up);
            if (flatFwd.sqrMagnitude < 1e-4f) flatFwd = transform.forward;
            float yaw = Quaternion.LookRotation(flatFwd, Vector3.up).eulerAngles.y;
            transform.rotation = Quaternion.Euler(0f, yaw, 0f);
        }

        if (firstPersonController != null) firstPersonController.enabled = true;
        _magnetActive = false;

        if (debugLogging) Debug.Log("[MagnetWalker] DETACHED");
    }

    private void TickMagnet()
    {
        if (!FindBestSurface(out var hit) || hit.distance > detachDistance)
        {
            if (debugLogging) Debug.Log("[MagnetWalker] Lost wall -> Detach");
            Detach();
            return;
        }

        _currentNormal = hit.normal;
        float normalDelta = Vector3.Angle(_lastNormal, _currentNormal);
        if (normalDelta > maxNormalChangeToDetach)
        {
            if (debugLogging) Debug.Log("[MagnetWalker] Normal changed too much -> Detach");
            Detach();
            return;
        }
        _lastNormal = _currentNormal;

        // Camera look on wall
        if (_inputs != null && cameraTarget != null)
        {
            _yaw   += _inputs.look.x * lookSensitivity.x * Time.deltaTime;
            _pitch -= _inputs.look.y * lookSensitivity.y * Time.deltaTime;
            _pitch  = Mathf.Clamp(_pitch, pitchLimits.x, pitchLimits.y);

            Vector3 fFlat = Quaternion.AngleAxis(_yaw, _currentNormal) *
                            ProjectOnPlane(transform.forward, _currentNormal).normalized;
            Vector3 right = Vector3.Cross(_currentNormal, fFlat).normalized;
            Quaternion camRot = Quaternion.LookRotation(
                Quaternion.AngleAxis(_pitch, right) * fFlat,
                _currentNormal
            );
            cameraTarget.rotation = camRot;
        }

        // Align player up to wall
        Quaternion targetUp = Quaternion.FromToRotation(transform.up, _currentNormal) * transform.rotation;
        transform.rotation  = Quaternion.Slerp(transform.rotation, targetUp, Time.deltaTime * alignUpSlerp);

        // Move on wall plane + stick
        Vector2 raw = _inputs != null ? _inputs.move : Vector2.zero;
        _smoothedMove = Vector2.Lerp(_smoothedMove, raw, 1f - Mathf.Exp(-inputSmoothing * Time.deltaTime));

        Vector3 camFwd   = cameraTarget ? cameraTarget.forward : transform.forward;
        Vector3 camRight = cameraTarget ? cameraTarget.right   : transform.right;

        Vector3 forwardWall = ProjectOnPlane(camFwd,   _currentNormal).normalized;
        Vector3 rightWall   = ProjectOnPlane(camRight, _currentNormal).normalized;

        Vector3 move  = (forwardWall * _smoothedMove.y + rightWall * _smoothedMove.x) * wallMoveSpeed;
        Vector3 stick = -_currentNormal * stickForce;

        // keep capsule slightly off the wall
        Vector3 keepOff = hit.point + _currentNormal * snapOffset - transform.position;

        _cc.Move((move + stick + keepOff * 10f) * Time.deltaTime);
    }

    // -------- robust probe: OverlapSphere + SphereCast (optional backfaces) --------
    private bool FindBestSurface(out RaycastHit bestHit)
    {
        bestHit = new RaycastHit();
        float bestDist = float.MaxValue;

        if (magneticLayers.value == 0)
        {
            if (debugLogging) Debug.LogWarning("[MagnetWalker] 'magneticLayers' is 0 — set your wall layer.");
            return false;
        }

        // Temporarily allow backface hits if requested
        bool prevBackfaces = Physics.queriesHitBackfaces;
        if (queriesHitBackfaces) Physics.queriesHitBackfaces = true;

        try
        {
            // Probe around capsule mid height
            float mid = _cc ? Mathf.Clamp(_cc.height * 0.45f, 0.6f, 1.2f) : 0.8f;
            Vector3 origin = transform.position + Vector3.up * mid;

            Collider[] cols = Physics.OverlapSphere(origin, detectRadius, magneticLayers, QueryTriggerInteraction.Ignore);
            if (cols.Length == 0) return false;

            foreach (var col in cols)
            {
                if (!string.IsNullOrEmpty(magneticTag) && !col.CompareTag(magneticTag)) continue;

                Vector3 closest = col.ClosestPoint(origin);
                Vector3 dir = (closest - origin);
                float   dist = dir.magnitude;
                if (dist < 1e-4f) continue;
                dir /= dist;

                // SphereCast outward to get a clean normal
                if (Physics.SphereCast(origin, probeRadius, dir, out RaycastHit hit, detectRadius + 0.5f, magneticLayers, QueryTriggerInteraction.Ignore))
                {
                    // Pick nearest valid hit
                    if (hit.distance < bestDist)
                    {
                        bestDist = hit.distance;
                        bestHit  = hit;
                    }
                }
            }

            return bestDist < float.MaxValue;
        }
        finally
        {
            if (queriesHitBackfaces) Physics.queriesHitBackfaces = prevBackfaces;
        }
    }

    // -------- helpers --------
    private Vector3 GetAimForward() => cameraTarget ? cameraTarget.forward : transform.forward;
    private static Vector3 ProjectOnPlane(Vector3 v, Vector3 n) => v - Vector3.Dot(v, n) * n;
    private static float SignedAngleOnPlane(Vector3 from, Vector3 to, Vector3 n)
    {
        Vector3 f = ProjectOnPlane(from, n).normalized;
        Vector3 t = ProjectOnPlane(to,   n).normalized;
        return Vector3.SignedAngle(f, t, n);
    }

    void OnValidate()
    {
        if (detachDistance < detectRadius + 0.5f) detachDistance = detectRadius + 0.5f;
    }

    void OnDrawGizmosSelected()
    {
        if (!drawGizmos) return;
        if (_cc == null) return;
        float mid = Mathf.Clamp(_cc.height * 0.45f, 0.6f, 1.2f);
        Vector3 origin = transform.position + Vector3.up * mid;
        Gizmos.color = Color.cyan; Gizmos.DrawWireSphere(origin, detectRadius);
        Gizmos.color = Color.magenta; Gizmos.DrawRay(transform.position, _currentNormal); // last normal
    }
}
